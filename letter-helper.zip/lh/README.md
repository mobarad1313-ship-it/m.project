# Letter Helper
Upload a letter (photo/PDF) -> plain-language explanation in 40 languages, steps, deadline, scam check, English reply draft. 1 free letter, then $19/mo (Personal) or $149/mo (Organisation) via Stripe.

1. Supabase: run `supabase/schema.sql`; enable Email auth; add `{APP_URL}` to redirect URLs.
2. Copy `.env.example` to `.env.local`; add Supabase keys, `ANTHROPIC_API_KEY` (console.anthropic.com), Stripe secret key.
3. Stripe webhook -> `{APP_URL}/api/stripe` (checkout.session.completed, customer.subscription.deleted, invoice.payment_failed). Locally: `stripe listen --forward-to localhost:3000/api/stripe`.
4. `npm i && npm run dev`. Test card 4242 4242 4242 4242.
Before launch: add a Privacy Policy and Terms (you handle personal letters), and consider rate limiting `/api/analyze`.
