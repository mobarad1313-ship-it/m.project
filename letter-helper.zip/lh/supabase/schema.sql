create table profiles (
  id uuid primary key references auth.users on delete cascade,
  plan text not null default 'free',      -- free | person | org
  free_used int not null default 0,       -- 1 free letter
  stripe_subscription text
);
create table letters (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  language text, result jsonb not null,
  created_at timestamptz default now()
);
alter table profiles enable row level security;
alter table letters enable row level security;
create policy own_p on profiles for select using (id = auth.uid());
create policy own_l on letters for select using (user_id = auth.uid());
create policy del_l on letters for delete using (user_id = auth.uid());
-- The uploaded file itself is never stored; only the result.
