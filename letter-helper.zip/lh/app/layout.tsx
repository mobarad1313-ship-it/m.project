import "./globals.css";
export const metadata = { title: "Letter Helper", description: "Confusing letter? Upload it. Get a plain-language explanation, what to do, and a reply, in your language." };
export default function Root({ children }: { children: React.ReactNode }) { return <html lang="en-AU"><body>{children}</body></html>; }
