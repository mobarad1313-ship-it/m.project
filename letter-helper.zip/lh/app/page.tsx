"use client";
import { useEffect, useState } from "react";
import { browser } from "@/lib/supabase";
import { LANGS, RTL } from "@/lib/languages";

const sb = browser();

export default function Home() {
  const [session, setSession] = useState<any>(null), [ready, setReady] = useState(false);
  const [email, setEmail] = useState(""), [sent, setSent] = useState(false);
  const [file, setFile] = useState<File | null>(null), [lang, setLang] = useState("English"), [note, setNote] = useState("");
  const [busy, setBusy] = useState(false), [err, setErr] = useState(""), [res, setRes] = useState<any>(null), [hist, setHist] = useState<any[]>([]), [plan, setPlan] = useState("free");

  useEffect(() => {
    sb.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true); });
    const { data: l } = sb.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => l.subscription.unsubscribe();
  }, []);
  useEffect(() => { if (session) refresh(); }, [session]);
  async function refresh() {
    const [h, p] = await Promise.all([sb.from("letters").select("*").order("created_at", { ascending: false }).limit(20), sb.from("profiles").select("plan").maybeSingle()]);
    setHist(h.data || []); setPlan(p.data?.plan || "free");
  }
  async function login() { await sb.auth.signInWithOtp({ email, options: { emailRedirectTo: location.origin } }); setSent(true); }
  async function analyze() {
    setBusy(true); setErr(""); setRes(null);
    const fd = new FormData(); fd.append("file", file!); fd.append("language", lang); fd.append("note", note);
    const r = await fetch("/api/analyze", { method: "POST", headers: { Authorization: `Bearer ${session.access_token}` }, body: fd });
    const j = await r.json(); setBusy(false);
    if (j.result) { setRes({ ...j.result, language: lang }); refresh(); } else setErr(j.error === "upgrade" ? "upgrade" : j.error);
  }
  async function buy(plan: string) {
    const r = await fetch("/api/checkout", { method: "POST", headers: { Authorization: `Bearer ${session.access_token}`, "Content-Type": "application/json" }, body: JSON.stringify({ plan }) });
    const j = await r.json(); if (j.url) location.href = j.url;
  }

  const Result = ({ r, language }: any) => (
    <div className="card" dir={RTL.includes(language) ? "rtl" : "ltr"}>
      <span className={`tag ${r.urgency}`}>Urgency: {r.urgency}</span> <b>{r.sender}</b>
      <p>{r.summary}</p>
      <b>What to do</b><ul>{r.what_to_do?.map((s: string, i: number) => <li key={i}>{s}</li>)}</ul>
      <p><b>Deadline:</b> {r.deadline}</p>
      <p><b>Is it genuine?</b> {r.scam_check}</p>
      {!!r.questions_to_ask?.length && <><b>Good questions to ask</b><ul>{r.questions_to_ask.map((s: string, i: number) => <li key={i}>{s}</li>)}</ul></>}
      <b dir="ltr">Draft reply (English)</b><pre dir="ltr">{r.reply_draft}</pre>
      <button className="ghost" dir="ltr" onClick={() => navigator.clipboard.writeText(r.reply_draft)}>Copy reply</button>
      <p className="mute" dir="ltr">General information only, not legal or financial advice. For big amounts, court, visas or short deadlines, contact the sender or a free service like Legal Aid.</p>
    </div>
  );

  if (!ready) return <main />;
  if (!session) return (
    <main>
      <h1>Got a letter you don't understand?</h1>
      <p className="sub">Take a photo. Get a plain explanation, what to do and by when, plus a reply you can send. In your language.</p>
      <div className="card">
        <label>Your email<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" /></label>
        <button onClick={login} disabled={!email.includes("@")}>Try it free (1 letter)</button>
        {sent && <p>Check your email for the sign-in link.</p>}
      </div>
      <p className="mute">ATO, Centrelink, fines, council, landlord, bank, employer. Works in 40 languages. Then $19/month for unlimited letters.</p>
    </main>
  );
  return (
    <main>
      <h1 style={{ fontSize: "2rem" }}>Upload a letter</h1>
      <div className="card">
        <label>Photo or PDF of the letter<input type="file" accept="image/*,application/pdf" onChange={(e) => setFile(e.target.files?.[0] || null)} /></label>
        <label>Explain it in<select value={lang} onChange={(e) => setLang(e.target.value)}>{LANGS.map((l) => <option key={l}>{l}</option>)}</select></label>
        <label>Anything we should know? (optional)<textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} /></label>
        <button onClick={analyze} disabled={!file || busy}>{busy ? "Reading your letter…" : "Explain this letter"}</button>
        {err && err !== "upgrade" && <p className="err" role="alert">{err}</p>}
      </div>
      {err === "upgrade" && (<div><p><b>Your free letter is used.</b> Choose a plan to keep going.</p><div className="plans">
        <div className="card"><b>Personal</b><br />$19/month<br /><span className="mute">Unlimited letters</span><button onClick={() => buy("person")}>Choose Personal</button></div>
        <div className="card"><b>Organisation</b><br />$149/month<br /><span className="mute">For community services, agencies, employers</span><button onClick={() => buy("org")}>Choose Organisation</button></div></div></div>)}
      {res && <Result r={res} language={res.language} />}
      {!!hist.length && <><h2>Your letters</h2>{hist.map((h) => <details className="card" key={h.id}><summary>{h.result.sender} · {new Date(h.created_at).toLocaleDateString("en-AU")}</summary><Result r={h.result} language={h.language} /></details>)}</>}
      <p className="mute">Plan: {plan} · Your uploaded files are not stored, only the explanations. <a href="#" onClick={(e) => { e.preventDefault(); sb.auth.signOut(); }}>Sign out</a></p>
    </main>
  );
}
