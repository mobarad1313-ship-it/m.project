import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { admin } from "@/lib/supabase";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
const PLANS: any = { person: { name: "Letter Helper (Personal)", amount: 1900 }, org: { name: "Letter Helper (Organisation)", amount: 14900 } };

export async function POST(req: NextRequest) {
  const { data: { user } } = await admin.auth.getUser(req.headers.get("authorization")?.replace("Bearer ", "") || "");
  if (!user) return NextResponse.json({ error: "Sign in first" }, { status: 401 });
  const { plan } = await req.json();
  const p = PLANS[plan];
  if (!p) return NextResponse.json({ error: "Bad plan" }, { status: 400 });
  const s = await stripe.checkout.sessions.create({
    mode: "subscription", customer_email: user.email!, metadata: { uid: user.id, plan },
    line_items: [{ quantity: 1, price_data: { currency: "aud", unit_amount: p.amount, recurring: { interval: "month" }, product_data: { name: p.name } } }],
    success_url: `${process.env.APP_URL}/?paid=1`, cancel_url: `${process.env.APP_URL}/`,
  });
  return NextResponse.json({ url: s.url });
}
