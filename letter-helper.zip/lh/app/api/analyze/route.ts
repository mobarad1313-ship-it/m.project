import { NextRequest, NextResponse } from "next/server";
import { admin } from "@/lib/supabase";

export const maxDuration = 60;
const SYSTEM = `You help everyday people in Australia understand official letters (government, council, fines, tax, Centrelink, banks, landlords, employers, insurers). Reply ONLY with JSON:
{"sender":"who sent it","summary":"plain explanation in 2-4 short sentences","what_to_do":["step",...],"deadline":"date/time limit or 'None stated'","urgency":"low|medium|high","scam_check":"is this likely genuine, or does it show scam signs? say why in one sentence","questions_to_ask":["useful question to ask the sender or an adviser"],"reply_draft":"a polite draft reply, in English, ready to send, using [PLACEHOLDERS] for unknown details"}
Write every field except reply_draft in the language requested. Use simple words (reading age ~12). Never invent facts not in the letter; if something is unclear, say so. This is general information, not legal or financial advice: for large amounts, court, visas, or deadlines under 7 days, suggest contacting the sender or a free service (community legal centre, Legal Aid).`;

export async function POST(req: NextRequest) {
  const { data: { user } } = await admin.auth.getUser(req.headers.get("authorization")?.replace("Bearer ", "") || "");
  if (!user) return NextResponse.json({ error: "Sign in first" }, { status: 401 });

  await admin.from("profiles").upsert({ id: user.id }, { onConflict: "id", ignoreDuplicates: true });
  const { data: p } = await admin.from("profiles").select("*").eq("id", user.id).single();
  if (p.plan === "free" && p.free_used >= 1) return NextResponse.json({ error: "upgrade" }, { status: 402 });

  const form = await req.formData();
  const file = form.get("file") as File, language = String(form.get("language") || "English"), note = String(form.get("note") || "");
  if (!file || file.size > 5_000_000) return NextResponse.json({ error: "Add a photo or PDF under 5 MB" }, { status: 400 });
  const type = file.type === "application/pdf" ? "document" : "image";
  if (type === "image" && !/^image\/(jpeg|png|webp|gif)$/.test(file.type)) return NextResponse.json({ error: "Use JPG, PNG or PDF" }, { status: 400 });
  const data = Buffer.from(await file.arrayBuffer()).toString("base64");

  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": process.env.ANTHROPIC_API_KEY!, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5", max_tokens: 2000, system: SYSTEM,
      messages: [{ role: "user", content: [
        { type, source: { type: "base64", media_type: file.type, data } },
        { type: "text", text: `Language for the explanation: ${language}.${note ? ` The person says: ${note}` : ""}` },
      ] }],
    }),
  });
  const j = await r.json();
  if (!r.ok) return NextResponse.json({ error: "Couldn't read that letter. Try a clearer photo." }, { status: 502 });
  let result;
  try { result = JSON.parse(j.content[0].text.replace(/```json|```/g, "").trim()); }
  catch { return NextResponse.json({ error: "Couldn't read that letter. Try a clearer photo." }, { status: 502 }); }

  await admin.from("letters").insert({ user_id: user.id, language, result });
  if (p.plan === "free") await admin.from("profiles").update({ free_used: p.free_used + 1 }).eq("id", user.id);
  return NextResponse.json({ result });
}
