import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { admin } from "@/lib/supabase";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

export async function POST(req: NextRequest) {
  let ev: Stripe.Event;
  try { ev = stripe.webhooks.constructEvent(await req.text(), req.headers.get("stripe-signature")!, process.env.STRIPE_WEBHOOK_SECRET!); }
  catch { return new NextResponse("bad signature", { status: 400 }); }
  if (ev.type === "checkout.session.completed") {
    const s = ev.data.object as Stripe.Checkout.Session;
    await admin.from("profiles").upsert({ id: s.metadata!.uid, plan: s.metadata!.plan, stripe_subscription: s.subscription as string });
  }
  if (ev.type === "customer.subscription.deleted" || ev.type === "invoice.payment_failed") {
    const o: any = ev.data.object;
    await admin.from("profiles").update({ plan: "free" }).eq("stripe_subscription", ev.type === "invoice.payment_failed" ? o.subscription : o.id);
  }
  return NextResponse.json({ ok: true });
}
